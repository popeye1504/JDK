import java.util.Arrays;
import java.util.Scanner;

public class Priority1
{
   private Scanner sc;
   public void execute()
   {
     sc=new Scanner(System.in);
     System.out.println("Enter the number of Processes");
     int numprocess=sc.nextInt();
     int at,bt,pr;
     Process1[] process=new Process1[numprocess];
     for(int i=0;i<numprocess;i++)
     {
        System.out.println("P("+(i+1)+"): Enter the burst time and priority ");
        at=0;
        bt=sc.nextInt();
        pr=sc.nextInt();
        process[i]=new Process1("P"+(i+1),bt,at,pr);
     } 
     
     Arrays.sort(process,new SortByPriority());
     
     int sum=0;
     double avgTAT=0,avgWT=0;
     System.out.println("\n\nPRNo\tBT\tAT\tCT\tTAT\tWT\tPR");
     System.out.println("======================================================================================");
     for(int i=0;i<numprocess;i++)
     {
        sum=process[i].CT=sum+process[i].BT;
        process[i].TAT=process[i].CT-process[i].AT;
        process[i].WT=process[i].TAT-process[i].BT;
        avgTAT=avgTAT+process[i].TAT;
        avgWT=avgWT+process[i].WT;
        process[i].display();
     }
     avgTAT=(double)avgTAT/numprocess;
     avgWT=(double)avgWT/numprocess;
     System.out.println("The average Turnaround time "+avgTAT);
     System.out.println("The average Waiting time "+avgWT);
   }
   public static void main(String[] args)
   {
       Priority1 p=new Priority1();
       p.execute();
   }
}
