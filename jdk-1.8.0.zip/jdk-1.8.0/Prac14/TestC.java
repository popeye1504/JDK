import java.util.*;

public class TestC
{
   public native int add(int n1,int n2);
   public native int sub(int n1,int n2);
   public native int mul(int n1,int n2);  // native to import externally function
   public native float div(int n1,int n2);
   public static void main(String[] args)
   {
      TestC t=new TestC();
      System.out.println("Enter the choice: \n 1.ADDITION \n 2. SUBTRACTION \n 3.MULTIPLICATION \n 4.DIVISION \n");
      Scanner sc=new Scanner(System.in);
      int ch=sc.nextInt();
      System.out.println("Enter the operands");
      int a=sc.nextInt();
      int b=sc.nextInt();
      switch(ch)
      {
         case 1:
           System.out.println("The sum is "+t.add(a,b));
           break;
         case 2:
           System.out.println("The difference is "+t.sub(a,b));
           break;
         case 3:
           System.out.println("The product is "+t.mul(a,b));
           break;
         case 4:
           System.out.println("The division is "+t.div(a,b));
           break;
           
      }
   }
   static
   {
      System.loadLibrary("TestC"); 
   }
}
