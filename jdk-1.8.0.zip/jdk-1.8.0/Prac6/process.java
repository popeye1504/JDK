import java.util.Comparator;
public class process{
     int BT,AT,CT,TAT,WT,PR,remBT;
     String name;
     boolean flag;
     public process(String name,int at,int bt)
     {
         this.name=name;
         BT=bt;
         AT=at;
         remBT=BT;
         TAT=WT=CT=0;
         PR=0;
     }
      public void display()
     {
        System.out.println(""+name+"\t"+BT+"\t"+AT+"\t"+CT+"\t"+TAT+"\t"+WT+"\t"+PR);
     }
 }